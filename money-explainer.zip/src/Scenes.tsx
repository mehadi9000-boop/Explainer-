import React from 'react';
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { theme, FONT } from './theme';
import { Person, House, Coin, Lock, Warn, Check, UpArrow, Bill } from './icons';

// Shared canvas: 1080x1920 SVG with a faint dot grid.
const Canvas: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <AbsoluteFill style={{ background: theme.bg }}>
    <svg viewBox="0 0 1080 1920" width="100%" height="100%" style={{ fontFamily: FONT }}>
      <defs>
        <pattern id="dots" width="48" height="48" patternUnits="userSpaceOnUse">
          <circle cx="2" cy="2" r="3" fill={theme.border} />
        </pattern>
      </defs>
      <rect width="1080" height="1920" fill="url(#dots)" />
      {children}
    </svg>
  </AbsoluteFill>
);

// Spring-in progress for the current scene's local frame.
export const useEnter = (delay = 0) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config: { damping: 11, stiffness: 170, mass: 0.8 } });
};

const Pop: React.FC<{ delay?: number; rise?: number; children: React.ReactNode }> = ({
  delay = 0, rise = 40, children,
}) => {
  const p = useEnter(delay);
  return <g opacity={p} transform={`translate(0 ${(1 - p) * rise})`}>{children}</g>;
};

const Chip: React.FC<{ x: number; y: number; text: string; color: string }> = ({ x, y, text, color }) => {
  const w = text.length * 26 + 64;
  return (
    <g>
      <rect x={x - w / 2} y={y - 42} width={w} height={84} rx={42} fill={theme.surfaceHi} stroke={color} strokeWidth={3} />
      <text x={x} y={y + 14} textAnchor="middle" fontSize={44} fontWeight={700} fill={theme.text}>
        {text}
      </text>
    </g>
  );
};

// 1. Two people, two ways with money (0:00 - 0:19)
export const SceneTwoPeople: React.FC = () => {
  const f = useCurrentFrame();
  const jar = interpolate(f, [0, 360], [0, 236], { extrapolateRight: 'clamp' });
  const coins = [0, 1, 2, 3, 4, 5, 6];
  const check = useEnter(500);
  return (
    <Canvas>
      <Pop><Person x={300} y={780} s={1.2} color={theme.data} /></Pop>
      {/* saver's jar filling up */}
      <rect x={210} y={1350} width={180} height={246} rx={20} fill="none" stroke={theme.muted} strokeWidth={4} />
      <rect x={216} y={1590 - jar} width={168} height={jar} fill={theme.warn} />
      <Pop delay={10}><Person x={780} y={780} s={1.2} color={theme.text} /></Pop>
      {/* spender's coins falling away */}
      {coins.map((i) => {
        const cy = 480 + ((f * 5 + i * 130) % 900);
        return <Coin key={i} x={900 + (i % 3) * 30} y={cy} color={theme.warn} opacity={0.85} />;
      })}
      <g opacity={check}>
        <Check x={300} y={560} s={1.6} color={theme.good} />
        <Check x={780} y={560} s={1.6} color={theme.good} />
      </g>
    </Canvas>
  );
};

// 2. David's childhood (0:19 - 0:36)
export const SceneDavid: React.FC = () => {
  const f = useCurrentFrame();
  const bills = [0, 1, 2];
  return (
    <Canvas>
      <Pop><Chip x={540} y={300} text="David" color={theme.data} /></Pop>
      <Pop delay={5}><House x={540} y={560} s={1.5} color={theme.surfaceHi} /></Pop>
      {/* empty cupboard */}
      <rect x={430} y={700} width={220} height={140} fill="none" stroke={theme.muted} strokeWidth={4} strokeDasharray="12 10" />
      {/* unpaid bills landing on the table */}
      {bills.map((k) => {
        const start = 90 + k * 60;
        const y = interpolate(f, [start, start + 40], [240, 1250], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
        return <Bill key={k} x={480 + k * 70} y={y} color={theme.warn} />;
      })}
      <rect x={300} y={1280} width={480} height={24} fill={theme.surfaceHi} />
      <Pop delay={20}><Person x={180} y={1080} s={0.9} color={theme.data} /></Pop>
      <Pop delay={30}><Person x={900} y={1080} s={0.9} color={theme.muted} opacity={0.75} /></Pop>
    </Canvas>
  );
};

// 3. David's promise (0:36 - 0:43)
export const SceneDavidPromise: React.FC = () => {
  const f = useCurrentFrame();
  const ring = interpolate(f % 60, [0, 60], [200, 320]);
  const ringOpacity = interpolate(f % 60, [0, 60], [0.6, 0]);
  return (
    <Canvas>
      <Pop><Chip x={540} y={300} text="David" color={theme.data} /></Pop>
      <circle cx={540} cy={860} r={ring} fill="none" stroke={theme.accent} strokeWidth={4} opacity={ringOpacity} />
      <Pop delay={5}><Lock x={540} y={860} s={1.6} color={theme.accent} /></Pop>
      <Pop delay={15}><Person x={540} y={1360} s={0.9} color={theme.data} /></Pop>
    </Canvas>
  );
};

// 4. Alex's world (0:43 - 0:57)
export const SceneAlex: React.FC = () => {
  const f = useCurrentFrame();
  const coins = [0, 1, 2, 3, 4, 5, 6, 7, 8];
  return (
    <Canvas>
      <Pop><Chip x={540} y={300} text="Alex" color={theme.flow} /></Pop>
      <Pop delay={5}><House x={540} y={640} s={1.6} color={theme.flow} /></Pop>
      {coins.map((i) => {
        const cy = 1500 - ((f * 3 + i * 90) % 900);
        return <Coin key={i} x={130 + i * 100} y={cy} color={theme.good} opacity={0.8} />;
      })}
      <Pop delay={20}><Person x={540} y={1330} s={0.9} color={theme.flow} /></Pop>
    </Canvas>
  );
};

// 5. Two childhoods side by side (0:57 - 1:09)
export const SceneCompare: React.FC = () => (
  <Canvas>
    <Pop><Chip x={270} y={300} text="David" color={theme.data} /></Pop>
    <Pop><Chip x={810} y={300} text="Alex" color={theme.flow} /></Pop>
    <line x1={540} y1={380} x2={540} y2={1520} stroke={theme.border} strokeWidth={4} strokeDasharray="14 12" />
    <Pop delay={5}><House x={270} y={740} s={0.9} color={theme.muted} /></Pop>
    <Pop delay={10}><House x={810} y={740} s={0.9} color={theme.flow} /></Pop>
    <Pop delay={20}><Person x={270} y={1240} s={0.8} color={theme.data} /></Pop>
    <Pop delay={25}><Person x={810} y={1240} s={0.8} color={theme.flow} /></Pop>
  </Canvas>
);

// 6. Risk as threat vs opportunity, then beliefs from experience (1:09 - 1:38)
export const SceneRisk: React.FC = () => (
  <Canvas>
    <Pop><Person x={270} y={900} s={1} color={theme.data} /></Pop>
    <Pop><Person x={810} y={900} s={1} color={theme.flow} /></Pop>
    <Pop delay={15}><Warn x={270} y={560} s={0.9} color={theme.bad} /></Pop>
    <Pop delay={30}><Chip x={270} y={1270} text="Threat" color={theme.bad} /></Pop>
    <Pop delay={200}><UpArrow x={810} y={560} s={2} color={theme.good} /></Pop>
    <Pop delay={215}><Chip x={810} y={1270} text="Opportunity" color={theme.good} /></Pop>
    <Pop delay={330}><Chip x={300} y={1560} text="Experience" color={theme.muted} /></Pop>
    <Pop delay={360}><Chip x={780} y={1560} text="Belief" color={theme.accent} /></Pop>
  </Canvas>
);

// 7. Closing line: no one is crazy (1:28 - 1:38)
export const SceneLesson: React.FC = () => (
  <Canvas>
    <Pop><Person x={300} y={900} s={1} color={theme.data} /></Pop>
    <Pop delay={5}><Person x={780} y={900} s={1} color={theme.flow} /></Pop>
    <Pop delay={160}><Check x={540} y={880} s={2.2} color={theme.good} /></Pop>
  </Canvas>
);

