export type Cue = { start: number; end: number; words: string[] };

export const CUES: Cue[] = [
  {
    "start": 0,
    "end": 6080,
    "words": [
      "Imagine",
      "two",
      "people,",
      "one",
      "saves",
      "every",
      "penny",
      "he",
      "earns,",
      "the",
      "other",
      "spends",
      "money",
      "whenever",
      "he",
      "gets",
      "the"
    ]
  },
  {
    "start": 6080,
    "end": 12160,
    "words": [
      "chance.",
      "The",
      "first",
      "person",
      "thinks",
      "the",
      "second",
      "is",
      "irresponsible.",
      "The",
      "second",
      "thinks",
      "the",
      "first",
      "is"
    ]
  },
  {
    "start": 12160,
    "end": 18160,
    "words": [
      "wasting",
      "his",
      "life.",
      "But",
      "here's",
      "something",
      "interesting.",
      "Neither",
      "of",
      "them",
      "is",
      "necessarily",
      "wrong."
    ]
  },
  {
    "start": 19120,
    "end": 24320,
    "words": [
      "Meet",
      "David.",
      "David",
      "grew",
      "up",
      "in",
      "a",
      "poor",
      "family.",
      "He",
      "watched",
      "his",
      "father",
      "lose",
      "everything",
      "during",
      "a"
    ]
  },
  {
    "start": 24320,
    "end": 29920,
    "words": [
      "financial",
      "crisis.",
      "He",
      "remembers",
      "the",
      "empty",
      "cupboards,",
      "unpaid",
      "bills",
      "and",
      "the",
      "fear",
      "of",
      "not",
      "knowing"
    ]
  },
  {
    "start": 29920,
    "end": 36080,
    "words": [
      "what",
      "tomorrow",
      "would",
      "bring.",
      "So",
      "David",
      "made",
      "a",
      "promise",
      "to",
      "himself.",
      "He",
      "would",
      "never",
      "be",
      "financially"
    ]
  },
  {
    "start": 36080,
    "end": 43200,
    "words": [
      "helpless",
      "again.",
      "Now",
      "meet",
      "Alex.",
      "Alex",
      "grew",
      "up",
      "in",
      "a",
      "completely",
      "different",
      "world.",
      "His",
      "family",
      "was"
    ]
  },
  {
    "start": 43200,
    "end": 50320,
    "words": [
      "financially",
      "secure.",
      "He",
      "never",
      "worried",
      "about",
      "food,",
      "rent",
      "or",
      "unexpected",
      "expenses.",
      "To",
      "him,",
      "money",
      "was"
    ]
  },
  {
    "start": 50320,
    "end": 57120,
    "words": [
      "something",
      "meant",
      "to",
      "be",
      "enjoyed.",
      "Two",
      "people.",
      "Two",
      "completely",
      "different",
      "childhoods",
      "and",
      "two",
      "completely"
    ]
  },
  {
    "start": 57120,
    "end": 62320,
    "words": [
      "different",
      "relationships",
      "with",
      "money.",
      "Now",
      "here's",
      "the",
      "lesson.",
      "We",
      "often",
      "judge",
      "people",
      "by",
      "their"
    ]
  },
  {
    "start": 62320,
    "end": 68720,
    "words": [
      "financial",
      "decisions",
      "without",
      "understanding",
      "the",
      "experiences",
      "that",
      "shaped",
      "them.",
      "Someone",
      "who",
      "grew",
      "up",
      "poor"
    ]
  },
  {
    "start": 68720,
    "end": 75680,
    "words": [
      "may",
      "see",
      "risk",
      "as",
      "a",
      "threat.",
      "Someone",
      "who",
      "grew",
      "up",
      "wealthy",
      "may",
      "see",
      "it",
      "as",
      "an",
      "opportunity.",
      "Neither"
    ]
  },
  {
    "start": 75680,
    "end": 81920,
    "words": [
      "perspective",
      "came",
      "out",
      "of",
      "nowhere.",
      "Their",
      "experiences",
      "created",
      "their",
      "beliefs.",
      "And",
      "that's",
      "why",
      "Morgan"
    ]
  },
  {
    "start": 81920,
    "end": 88480,
    "words": [
      "Housel",
      "makes",
      "a",
      "fascinating",
      "point",
      "in",
      "the",
      "psychology",
      "of",
      "money.",
      "People",
      "do",
      "some",
      "crazy",
      "things",
      "with",
      "money."
    ]
  },
  {
    "start": 89200,
    "end": 93840,
    "words": [
      "But",
      "no",
      "one",
      "is",
      "crazy.",
      "Because",
      "before",
      "judging",
      "someone's",
      "financial",
      "decisions,"
    ]
  },
  {
    "start": 95360,
    "end": 98320,
    "words": [
      "try",
      "understanding",
      "the",
      "life",
      "that",
      "taught",
      "them",
      "to",
      "make",
      "those",
      "decisions?"
    ]
  }
];
