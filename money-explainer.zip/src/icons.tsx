import React from 'react';
import { theme } from './theme';

type P = { x: number; y: number; s?: number; color: string; opacity?: number };

export const Person: React.FC<P> = ({ x, y, s = 1, color, opacity = 1 }) => (
  <g opacity={opacity}>
    <circle cx={x} cy={y} r={70 * s} fill={color} />
    <rect x={x - 120 * s} y={y + 90 * s} width={240 * s} height={330 * s} rx={110 * s} fill={color} />
  </g>
);

export const House: React.FC<P> = ({ x, y, s = 1, color }) => (
  <g>
    <polygon
      points={`${x - 230 * s},${y} ${x},${y - 190 * s} ${x + 230 * s},${y}`}
      fill={color}
    />
    <rect x={x - 190 * s} y={y} width={380 * s} height={280 * s} fill={color} />
    <rect x={x - 36 * s} y={y + 130 * s} width={72 * s} height={150 * s} fill={theme.bg} />
  </g>
);

export const Coin: React.FC<{ x: number; y: number; r?: number; color: string; opacity?: number }> = ({
  x, y, r = 22, color, opacity = 1,
}) => <circle cx={x} cy={y} r={r} fill={color} opacity={opacity} />;

export const Lock: React.FC<P> = ({ x, y, s = 1, color }) => (
  <g>
    <path
      d={`M ${x - 70 * s} ${y} V ${y - 50 * s} A ${70 * s} ${70 * s} 0 0 1 ${x + 70 * s} ${y - 50 * s} V ${y}`}
      fill="none"
      stroke={color}
      strokeWidth={22 * s}
    />
    <rect x={x - 110 * s} y={y} width={220 * s} height={170 * s} rx={24 * s} fill={color} />
  </g>
);

export const Warn: React.FC<P> = ({ x, y, s = 1, color }) => (
  <g>
    <polygon
      points={`${x},${y - 120 * s} ${x + 120 * s},${y + 90 * s} ${x - 120 * s},${y + 90 * s}`}
      fill={color}
    />
    <rect x={x - 12 * s} y={y - 50 * s} width={24 * s} height={85 * s} fill={theme.bg} />
    <circle cx={x} cy={y + 62 * s} r={12 * s} fill={theme.bg} />
  </g>
);

export const Check: React.FC<P> = ({ x, y, s = 1, color }) => (
  <polyline
    points={`${x - 60 * s},${y} ${x - 15 * s},${y + 45 * s} ${x + 60 * s},${y - 45 * s}`}
    fill="none"
    stroke={color}
    strokeWidth={26 * s}
    strokeLinecap="round"
    strokeLinejoin="round"
  />
);

export const UpArrow: React.FC<P> = ({ x, y, s = 1, color }) => (
  <g stroke={color} strokeWidth={26 * s} strokeLinecap="round" strokeLinejoin="round" fill="none">
    <polyline points={`${x},${y + 60 * s} ${x},${y - 60 * s}`} />
    <polyline points={`${x - 50 * s},${y - 10 * s} ${x},${y - 60 * s} ${x + 50 * s},${y - 10 * s}`} />
  </g>
);

export const Bill: React.FC<{ x: number; y: number; color: string }> = ({ x, y, color }) => (
  <g>
    <rect x={x - 60} y={y - 30} width={120} height={60} rx={6} fill={color} />
    <line x1={x - 36} y1={y} x2={x + 36} y2={y} stroke={theme.bg} strokeWidth={6} />
  </g>
);
