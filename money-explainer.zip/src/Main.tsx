import React from 'react';
import { AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame } from 'remotion';
import { theme } from './theme';
import { Captions } from './Captions';
import {
  SceneTwoPeople, SceneDavid, SceneDavidPromise, SceneAlex, SceneCompare, SceneRisk, SceneLesson,
} from './Scenes';

// Total length: 98.72 s of voiceover at 30 fps.
export const DURATION_FRAMES = 2962;

// Scene timings in frames, from the SRT (seconds x 30).
const SCENES = [
  { from: 0, dur: 573, C: SceneTwoPeople },     // 0:00 - 0:19
  { from: 573, dur: 510, C: SceneDavid },       // 0:19 - 0:36
  { from: 1083, dur: 213, C: SceneDavidPromise }, // 0:36 - 0:43
  { from: 1296, dur: 417, C: SceneAlex },       // 0:43 - 0:57
  { from: 1713, dur: 348, C: SceneCompare },    // 0:57 - 1:09
  { from: 2061, dur: 579, C: SceneRisk },       // 1:09 - 1:28
  { from: 2640, dur: 322, C: SceneLesson },     // 1:28 - 1:38
];

export const Main: React.FC = () => {
  const frame = useCurrentFrame();
  // fade to black over the last 20 frames
  const fade = interpolate(frame, [DURATION_FRAMES - 20, DURATION_FRAMES - 1], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{ background: theme.bg }}>
      {SCENES.map(({ from, dur, C }) => (
        <Sequence key={from} from={from} durationInFrames={dur}>
          <C />
        </Sequence>
      ))}
      <Audio src={staticFile('voiceover.mp3')} />
      <Captions />
      <AbsoluteFill style={{ background: theme.bg, opacity: fade }} />
    </AbsoluteFill>
  );
};


