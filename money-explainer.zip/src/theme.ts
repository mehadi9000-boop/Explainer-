// Colours are assigned by role. Change them here only.
export const theme = {
  bg: '#0A090C',
  surface: '#17171B',
  surfaceHi: '#222126',
  border: 'rgba(255,255,255,0.09)',
  text: '#F2F2F4',
  muted: '#8A8A92',
  accent: '#D8F838',
  onAccent: '#0A090C',
  data: '#5AC8FA',
  flow: '#4A8BF5',
  good: '#2E9A4A',
  warn: '#E89808',
  bad: '#E84838',
};

export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const FONT = 'Inter, Arial, Helvetica, sans-serif';
