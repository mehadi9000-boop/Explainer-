import React from 'react';
import { useCurrentFrame, useVideoConfig } from 'remotion';
import { CUES } from './captions';
import { theme, FONT } from './theme';

// Word-by-word captions synced to the SRT. Words in each cue are spaced
// evenly across the cue's time window, and the active word is highlighted.
export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const ms = (frame / fps) * 1000;

  // latest cue that has started
  let cue = null as (typeof CUES)[number] | null;
  for (const c of CUES) {
    if (c.start <= ms) cue = c;
  }
  if (!cue || ms > cue.end + 1200) return null;

  const n = cue.words.length;
  const dur = Math.max(1, cue.end - cue.start);
  const idx = ms > cue.end ? n : Math.min(n - 1, Math.floor(((ms - cue.start) / dur) * n));

  return (
    <div
      style={{
        position: 'absolute',
        top: 1398,
        left: 70,
        right: 70,
        transform: 'translateY(-50%)',
        background: theme.surfaceHi,
        border: `2px solid ${theme.border}`,
        borderRadius: 40,
        padding: '22px 36px',
        textAlign: 'center',
        fontFamily: FONT,
        fontSize: 62,
        fontWeight: 700,
        lineHeight: 1.15,
      }}
    >
      {cue.words.map((w, i) => (
        <span
          key={i}
          style={{
            color: i === idx ? theme.accent : i < idx ? theme.text : theme.muted,
            marginRight: 14,
          }}
        >
          {w}
        </span>
      ))}
    </div>
  );
};
