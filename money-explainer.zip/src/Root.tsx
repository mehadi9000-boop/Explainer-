import React from 'react';
import { Composition } from 'remotion';
import { Main, DURATION_FRAMES } from './Main';
import { FPS, W, H } from './theme';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    durationInFrames={DURATION_FRAMES}
    fps={FPS}
    width={W}
    height={H}
  />
);
