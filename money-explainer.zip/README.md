# money-explainer

Remotion project, 1080x1920 (9:16), 30 fps, 98.72 s.

## Setup (Windows, Node.js 18+)
1. npm install
2. npm run dev      (Remotion Studio preview)
3. npm run render   (writes out/video.mp4)

Files: public/voiceover.mp3 (narration), public/voiceover.srt (source timing).
Captions are in src/captions.ts, generated from the SRT. Edit scene timing in src/Main.tsx.
Colours are set by role in src/theme.ts.
